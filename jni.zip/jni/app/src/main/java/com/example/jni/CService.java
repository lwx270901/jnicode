package com.example.jni;


import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import android.widget.TextView;

public class CService extends Service {
    // Used to load the 'jni' library on application startup.
    static {
        System.loadLibrary("jni");
    }

    private MyBinder mBinder = new MyBinder();
    private boolean isUpdatingStopped;

    public class MyBinder extends Binder{
        CService getCService() {
            return CService.this;
        }
    }
    //Mot so ham quan trong cua vong doi cua mot service
    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("CService", "onCreate");
    }

    @Override
    public IBinder onBind(Intent intent){
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent){
        Log.e("CService", "onUnbind");
        return super.onUnbind(intent);
    }

    @Override
    public  void onDestroy() {
        super.onDestroy();
        Log.e("CService", "onDestroy");

    }

    public void startCService(){
        Log.e("CService", stringFromJNI());
    }

    public void startUpdatingNumbers(int number1, int number2) {
        isUpdatingStopped = false;
        new Thread(new Runnable() {
            @Override
            public void run() {
                startUpdatingNumbersNative(number1, number2);
            }
        }).start();
    }

    public boolean stopUpdatingNumbers() {
        isUpdatingStopped = true;
        return true;
    }
    private void updateScreen(int number1, int number2, int sum) {
        Log.e("CService", "Number 1: " + number1 + ", Number 2: " + number2 + ", Sum: " + sum);
        // Update the screen here with the updated numbers
    }

    /**
     * A native method that is implemented by the 'jni' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
    private native void startUpdatingNumbersNative(int number1, int number2);
}
