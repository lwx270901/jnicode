package com.example.jni;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.jni.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    // Used to load the 'jni' library on application startup.
//    static {
//        System.loadLibrary("jni");
//    }

    private ActivityMainBinding binding;

    private CService mCService;
    private boolean isServiceConnected;

    private EditText editTextNumber1;
    private EditText editTextNumber2;

    private ServiceConnection mserviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            CService.MyBinder myBinder = (CService.MyBinder) iBinder;
            mCService = myBinder.getCService();
            //Goi service
            mCService.startCService();
            int number1 = Integer.parseInt(editTextNumber1.getText().toString());
            int number2 = Integer.parseInt(editTextNumber2.getText().toString());
            mCService.startUpdatingNumbers(number1, number2);
            isServiceConnected = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isServiceConnected = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        editTextNumber1 = findViewById(R.id.editTextNumber1);
        editTextNumber2 = findViewById(R.id.editTextNumber2);

        // Example of a call to a native method
//        TextView tv = binding.sampleText;
        Button btnStartService = binding.btnStartService;
        Button btnStopService = binding.btnStopService;
//        tv.setText(stringFromJNI());

        btnStartService.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                onClickStartService();
            }
        });

        btnStopService.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                onClickStopService();
            }
        });

    }

    private void onClickStopService() {
        if(isServiceConnected)
        {
            unbindService(mserviceConnection);
            isServiceConnected = false;
        }
    }

    private void onClickStartService() {
        int number1 = 10; // Replace with your desired input number
        int number2 = 20; // Replace with your desired input number
        Intent intent = new Intent(this, CService.class);
        bindService(intent, mserviceConnection, Context.BIND_AUTO_CREATE);
//        if (isServiceConnected) {
//            mCService.startUpdatingNumbers(number1, number2);
//        }
    }

    /**
     * A native method that is implemented by the 'jni' native library,
     * which is packaged with this application.
     */
}