#include <jni.h>
#include <string>
#include <unistd.h>

//extern "C" JNIEXPORT jstring JNICALL
//Java_com_example_jni_MainActivity_stringFromJNI(
//        JNIEnv* env,
//        jobject /* this */) {
//    std::string hello = "Hello from C++";
//    return env->NewStringUTF(hello.c_str());
//}
extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_jni_CService_stringFromJNI(JNIEnv *env, jobject thiz) {
    // TODO: implement stringFromJNI()
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}
extern "C"
JNIEXPORT void JNICALL
Java_com_example_jni_CService_startUpdatingNumbersNative(JNIEnv *env, jobject thiz, jint number1,
                                                         jint number2) {
    // TODO: implement startUpdatingNumbersNative()
    jclass cls_CService = env->GetObjectClass(thiz);
    jmethodID method_updateScreen = env->GetMethodID(cls_CService, "updateScreen", "(III)V");
    jmethodID method_stopUpdatingNumbers = env->GetMethodID(cls_CService, "stopUpdatingNumbers", "()Z");

    int sum = number1 + number2;
    env->CallVoidMethod(thiz, method_updateScreen, number1, number2, sum);
    sleep(2); // Sleep for 5 seconds

    while (true) {
        number1 -= 1;
        number2 -= 1;
        sum = number1 + number2;
        env->CallVoidMethod(thiz, method_updateScreen, number1, number2, sum);
        sleep(3); // Sleep for 5 seconds

        // Check if stopUpdatingNumbers is called
        jboolean isUpdatingStopped = env->CallBooleanMethod(thiz, method_stopUpdatingNumbers);
        if (sum <= 0) {
            break; // Exit the loop if stopUpdatingNumbers is called
        }
    }
}